import {
  StyleSheet,
  Text,
  View,
  Button,
  TouchableOpacity,
  Image,
} from "react-native";
import React from "react";

export default function TouchableApp() {
  return (
    <View style={styles.container}>
      <Button title="normal button"></Button>
      <View>
        <TouchableOpacity style={[styles.button, { backgroundColor: "red" }]}>
          <Text>First Touch</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: "blue" }]}
          activeOpacity={0.1}
        >
          <Text>Second Touch</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.button, { backgroundColor: "#2277ee" }]}
        >
          <Image
            style={styles.logo}
            source={{ uri: "https://reactnative.dev/img/tiny_logo.png" }}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  button: {
    marginBottom: 12,
    padding: 12,
  },
  logo: {
    width: 100,
    height: 100,
  },
});
