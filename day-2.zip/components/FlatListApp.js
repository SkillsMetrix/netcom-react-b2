import { StyleSheet, Text, View, ScrollView,FlatList } from "react-native";
import React from "react";
import { persons } from "../models/persons";

export default function FlatListApp() {
    //show the seprator
    const myItem=()=>{
        return (
            <View style={{height:1,backgroundColor:'pink',marginHorizontal:10}}></View>
        )
    }
    //show empty message
    const myItemEmpty=()=>{
        return (
            <View style={{alignItems:'center'}}>
                <Text>Sorry, NO Items Found</Text>
            </View>
        )
    }
  return (
    <View style={styles.container}>
     
       <FlatList
       data={persons}
       renderItem={({item}) => <Text style={styles.item}>{item.name}</Text> }
       keyExtractor={(item)=> item.id}
       ItemSeparatorComponent={myItem}
       ListEmptyComponent={myItemEmpty}
       ListHeaderComponent={()=> <Text>User Details</Text>}
       ListFooterComponent={()=> <Text>Thats It....!</Text>}

       >

       </FlatList>
         



    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 50,
  },
  item: {
    padding: 20,
    fontSize: 15,
    marginTop: 5,
  },
});
