import {
  StyleSheet,
  Text,
  View,
  Image,
  FlatList,
  ActivityIndicator,
} from "react-native";
import React, { useEffect, useState } from "react";
import axios from "axios";
const URL = "https://randomuser.me/api/?page=3&results=10";
export default function InfiniteScrollApp() {
  const [users, setUsers] = useState([]);
  const [currentPage,setCurrentPage]=useState(1)
  const [isLoading,setIsLoading]=useState(false)

  const getUsers = () => {
    setIsLoading(true)
    axios.get(`https://randomuser.me/api/?page=${currentPage}&results=10`).then((res) => {
      setUsers([...users,...res.data.results]);
      setIsLoading(false)
    });
  };
  const renderItem = ({ item }) => {
    return (
      <View style={styles.itemWrapperStyle}>
        <View>
          <Image
            style={styles.ItemImage}
            source={{ uri: item.picture.large }}
          />
        </View>
        <View style={styles.contentWrapper}>
          <Text
            style={styles.txtName}
          >{`${item.name.title} ${item.name.first} ${item.name.last}`}</Text>
          <Text style={styles.txtEmail}>{item.email}</Text>
        </View>
      </View>
    );
  };
  const renderLoader = () => {
    return (
      <View style={styles.loaderStyle}>
        <ActivityIndicator size="large" color="red" />
      </View>
    );
  };
  const loadMoreItem = () => {
   setCurrentPage(currentPage+1)
  };
  useEffect(() => {
    getUsers();
  }, [currentPage]);
  return (
    <FlatList
      data={users}
      renderItem={renderItem}
      keyExtractor={(item) => item.email}
      ListFooterComponent={renderLoader}
      onEndReached={loadMoreItem}
    />
  );
}

const styles = StyleSheet.create({
  itemWrapperStyle: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: "lightblue",
  },
  ItemImage: {
    width: 50,
    height: 50,
    marginRight: 16,
  },
  contentWrapper: {
    justifyContent: "space-around",
  },
  txtName: { fontSize: 16 },
  txtEmail: { color: "blue" },
  loaderStyle: {
    marginVertical: 16,
    alignItems: "center",
  },
});
