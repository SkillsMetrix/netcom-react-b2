import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import TouchableApp from './components/TouchableApp';
import FlatListApp from './components/FlatListApp';
import InfiniteScrollApp from './components/InfiniteScrollApp';

export default function App() {
  return (
    <View style={styles.container}>
      <InfiniteScrollApp/>
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
