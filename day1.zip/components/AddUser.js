import { useState } from "react";
import { Button, Text, TextInput, View } from "react-native";

export default function AddUser(props) {
  // initilalize the sate of the component
  const [uname, setUname] = useState("");

  const addUser = () => {
    console.log(uname);
    props.au(uname);
  };

  return (
    <View>
      <TextInput
        placeholder="Enter UserName"
        value={uname}
        onChangeText={(newuser) => setUname(newuser)}
      ></TextInput>

      <Button title="Add User" onPress={addUser}></Button>
    </View>
  );
}
