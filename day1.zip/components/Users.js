

import { Text, StyleSheet, View } from 'react-native'
import React, { Component } from 'react'
import User from './User'

export default class Users extends Component {
  render() {
    return (
      <View>
        {this.props.userdata.map((data)=> <User key={data} 
        deleteuser={this.props.du}
        ud={data}/> )}
      
      </View>
    )
  }
}

const styles = StyleSheet.create({})