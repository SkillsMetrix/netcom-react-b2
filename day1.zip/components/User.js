
import { Text, StyleSheet, View, Button } from 'react-native'
import React, { Component } from 'react'

export default class User extends Component {
  render() {
    return (
      <View >
        <Text>{this.props.ud}</Text>
        <View>
          <Button onPress={()=> this.props.deleteuser(this.props.ud)} title='delete'></Button>
        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({})