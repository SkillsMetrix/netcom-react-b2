import React, { Component } from "react";
import { Text, View } from "react-native";
import Header from "./Header";
import Footer from "./Footer";
import AddUser from "./AddUser";
import Users from "./Users";
export default class MainApp extends Component {
  // initilalize the sate of the component
  state = {
    headerData: "Welcome to Header Component",
    userData: [''],
  };

  addUser = (user) => {
    this.setState((prevState) => {
      return {
        userData: prevState.userData.concat(user),
      };
    });
  };

  deleteAll=()=>{
    this.setState((prevState)=>{
      return{
        userData:[]
      }
    })
  }
  deleteUser=(data)=>{
    this.setState((prevState)=>{
      return{
        userData:prevState.userData.filter((option)=> data !== option)
      }
    })
  }
  render() {
    return (
      <View>
        <Header da={this.deleteAll} hdata={this.state.headerData} 
        hasData={!this.state.userData.length>0}
        />
        <AddUser  au={this.addUser}/>
        <Users userdata={this.state.userData}
        du={this.deleteUser}
        />
        <Footer />
      </View>
    );
  }
}
