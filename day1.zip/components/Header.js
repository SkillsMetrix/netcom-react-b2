import { Button, Text, View } from "react-native";
export default function Header(props) {
  return (
    <View>
      <Button
        disabled={props.hasData}
        onPress={props.da}
        title="Delete All"
      ></Button>
    </View>
  );
}
